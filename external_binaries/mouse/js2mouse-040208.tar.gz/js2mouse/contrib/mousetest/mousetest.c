    /*
    MouseTest
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h> //gettimeofday
#include <sys/poll.h>

#define DEFAULT_DEV "/dev/mouse"

int main( int argc, char **argv)
{
	int i;
	int fd=0;
	int rc=0;
	int num_bytes=3;
	int optch=0;

	char *buffer;
	char device[128+1];
	const char *optstring = "hd:n:";
	struct pollfd pollfd;

	/*struct timeval tv;
	/struct timeval old_tv;

        old_tv.tv_sec = 0;
        old_tv.tv_usec = 0;*/

	strncpy( device, DEFAULT_DEV, 128);
	device[128] = '\0';
	
	while ( -1 != (optch = getopt( argc, argv, optstring)) )
		switch ( optch ) {
			case 'h' : rc = 2;
				break;
			case 'd' : strncpy( device, optarg, 128);
				device[128] = '\0';
				break;
			case 'n' : num_bytes = atoi(optarg);
				if ( num_bytes == 0 ) rc = 1;
				break;
			default :
				rc = 1;
				break;
		}

	if ( rc ) {
		printf( "Usage : %s -d device -n num_bytes\n", argv[0]);
		return rc;
	}

	if ( NULL == (buffer = calloc( 1, num_bytes)) ) {
		perror("malloc");
		exit(1);
	}

	if ( -1 == (fd = open( device, O_RDONLY)) ) {
		perror(device);
		exit(1);
	}

	pollfd.fd = fd;
	pollfd.events = POLLIN;

	while ( 1 ) {
		if( -1 == poll(&pollfd, 1, -1) ) {
			perror("poll ");
			exit(1);
		}

		read( fd, buffer, num_bytes);

		for ( i=0; i<num_bytes; i++) {
			printf("b[%i]=%3i ", i, buffer[i] );

		}
		printf("\n");

		/*if ( -1 == gettimeofday( &tv, NULL) ) {
			perror("gettimeofday ");
			exit(1);
		}

		printf("%d\n", (tv.tv_sec-old_tv.tv_sec)*1000000+tv.tv_usec-old_tv.tv_usec);
		
		old_tv.tv_sec = tv.tv_sec;
		old_tv.tv_usec = tv.tv_usec;*/
	}

	free(buffer);
	return 0;
}
