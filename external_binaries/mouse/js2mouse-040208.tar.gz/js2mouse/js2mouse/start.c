    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
#include <string.h> //memset
#include <stdlib.h> //calloc, exit

#include "js2mouse.h"

#define max(a,b) (a>b?a:b)

void j2m_start( struct option_s *option)
{
	struct data_s data;
	struct pollfd poll_fd;
	
	unsigned char buff_size=0;
	unsigned char *map=NULL;
	char *mouse_buff=NULL;

	memset( &data, 0, sizeof(struct data_s));
	memset( &poll_fd, 0, sizeof(struct pollfd));

	if (option->poll_timeout == 0) {
		fprintf(stderr, "Error, poll(2) timeout must be > 0\n");
		exit(-1);
	}

	if ( !strncmp( option->proto, "ps2", 3) ) {
		buff_size =  j2m_buffsize_ps2();
		option->proto[0] = PS2;
	}
	else if ( !strncmp( option->proto, "imps2", 5) ) {
		buff_size =  j2m_buffsize_imps2();
		option->proto[0] = IMPS2;
	}
	else if ( !strncmp( option->proto, "exps2", 5) ) {
		buff_size =  j2m_buffsize_exps2();
		option->proto[0] = EXPS2;
	}
	else {
		fprintf( stderr, "Error, unknown mouse protocol : %s\n", option->proto);
		fprintf( stderr, "Valid mouse protocol are : ps2, imps2, exps2\n");
		exit(-1);
	}

	j2m_init( option, &data, buff_size);

	if (buff_size) {
		mouse_buff = (char *) calloc( buff_size, sizeof(char) );
		if ( mouse_buff == NULL ) {
			perror("Error when callocing for the mouse buffer ");
			exit(-1);
		}
	}

	map = (unsigned char *) calloc( max(data.number_of_axes+data.number_of_buttons+1, 10), sizeof(unsigned char) );
	if ( map == NULL ) {
		perror("Error when callocing for the map ");
		exit(-1);
	}

	poll_fd.events = POLLIN;
	poll_fd.fd = data.fd_joydev;

	if ( option->remap ) {
		j2m_remap( &(option->wanted_map) );
		
		if ( option->verbose ) {
			printf("click_left = button_%i\n", option->wanted_map.js_click_left);
			printf("click_right = button_%i\n", option->wanted_map.js_click_right);
			printf("click_middle = button_%i\n", option->wanted_map.js_click_middle);
			printf("click_extra1 = button_%i\n", option->wanted_map.js_click_extra1);
			printf("click_extra2 = button_%i\n", option->wanted_map.js_click_extra2);
			printf("wheel_up = button_%i\n", option->wanted_map.js_wheel_up);
			printf("wheel_down = button_%i\n", option->wanted_map.js_wheel_down);
			printf("move_horizontal = axe_%i\n", option->wanted_map.js_move_horizontal);
			printf("move_vertical = axe_%i\n", option->wanted_map.js_move_vertical);
		}
	
		j2m_create_map( &(option->wanted_map), map, data.number_of_axes, data.number_of_buttons);
	}
	else  j2m_create_default_map( map, data.number_of_axes, data.number_of_buttons);

	j2m_loop( &poll_fd, data.fd_joydev, data.fd_fifo, map, mouse_buff, buff_size, option->poll_timeout, option->proto[0]);
	
	return; //never reached
}





