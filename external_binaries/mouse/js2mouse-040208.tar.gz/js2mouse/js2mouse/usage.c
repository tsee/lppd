    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */

#include <stdio.h> //printf

#include "js2mouse.h"

void usage(char *prog_name)
{
	printf("Version : %s\n",__J2M_VERSION__);
	printf("Usage : %s [OPTION]...\n", prog_name);
	printf("Convert joystick inputs into mouse inputs\n\n");
	printf("\t-h\t\tshow this help\n");
	printf("\t-d <dev>\tuse specified device\tdefault : %s\n", DEFAULT_DEV);
	printf("\t-f <fifo>\tuse specified fifo\tdefault : %s\n", DEFAULT_FIFO);
	printf("\t-v <n>\t\tverbose level, 0 to 3\tdefault : %i\n", DEFAULT_VERBOSE);
	printf("\t-t <n>\t\tpoll(2) timeout in ms\tdefault : %i\n", DEFAULT_POLLTIMEOUT);
	printf("\t-r\t\tactive remapping keys\tdefault : disable\n");
	printf("\t-p\t\tuse specified mouse protocol\tdefault : %s\n", DEFAULT_PROTO);

	return;
}

