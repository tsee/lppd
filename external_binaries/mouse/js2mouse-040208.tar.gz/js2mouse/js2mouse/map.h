    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#ifndef __MAP_H__
#define __MAP_H__

#include <linux/joystick.h>

#define JS_CLICK_LEFT 0
#define JS_CLICK_RIGHT 1
#define JS_CLICK_MIDDLE 2
#define JS_WHEEL_UP 3
#define JS_WHEEL_DOWN  4
#define JS_MOVE_HORIZONTAL 5
#define JS_MOVE_VERTICAL 6
#define JS_CLICK_EXTRA1 7
#define JS_CLICK_EXTRA2 8
#define JS_UNUSED 10


struct map_s
{
	unsigned char js_click_left;
	unsigned char js_click_right;
	unsigned char js_click_middle;
	unsigned char js_click_extra1;
	unsigned char js_click_extra2;
	unsigned char js_wheel_up;
	unsigned char js_wheel_down;
	unsigned char js_move_vertical;
	unsigned char js_move_horizontal;
};


__u8 j2m_map_it( struct js_event *joy_event, unsigned char *map);
void j2m_create_default_map(unsigned char *map, unsigned char number_of_axes, unsigned char number_of_buttons);
void j2m_create_map( struct map_s *wanted_map, unsigned char *map, unsigned char number_of_axes, unsigned char number_of_buttons);


#endif //__MAP_H__
