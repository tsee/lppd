    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */

#include <sys/types.h> //mkfifo
#include <sys/stat.h>//mkfifo
#include <fcntl.h> //open
#include <stdlib.h> //exit
#include <string.h> //strncpy
#include <sys/ioctl.h> //ioctl
#include <errno.h> //errno
#include <stdio.h> //perror

#include "js2mouse.h"

void j2m_init( struct option_s *option, struct data_s *data, unsigned char buff_size)
{
	if ((data->fd_joydev = open( option->path_joydev, O_RDONLY|O_NONBLOCK)) < 0) {
		perror("Error when opening joystick device ");
		exit(-1);
	}
	
	if (buff_size) {
		if  ( mkfifo(option->path_fifo, 0666) && (errno != EEXIST) ) {
			perror("Error when creating mouse fifo ");
			exit(-1);
		}
		if ((data->fd_fifo = open( option->path_fifo, O_RDWR)) < 0) {
			perror("Error when opening mouse fifo for writing ");
			exit(-1);
		}
	}

	if ((ioctl( data->fd_joydev, JSIOCGAXES, &(data->number_of_axes))) < 0) {
		perror("Error when asking for number of axes ");
		exit(-1);
	}

	if ((ioctl( data->fd_joydev, JSIOCGBUTTONS, &(data->number_of_buttons))) < 0) {
		perror("Error when asking for number of buttons ");
		exit(-1);
	}
		
	if ((ioctl( data->fd_joydev, JSIOCGVERSION, &(data->driver_version))) < 0) {
		perror("Error when asking for joystick's driver version ");
		exit(-1);
	}


	if ( data->driver_version < 131328 ) {
		if ( data->driver_version < 100000 ) {
			fprintf(stderr,"Error : incompatible joystick's driver version\n");
			exit(-1);
		} else fprintf(stderr,"Warning : untested joystick's driver version\n");
	}
	
	if ( ioctl( data->fd_joydev, JSIOCGNAME(sizeof(data->joystick_name)), data->joystick_name) == -1 ) {
		strncpy( data->joystick_name, "Unknown", sizeof(data->joystick_name) );
	}

	switch ( option->verbose ) {
		case 3 :
			printf("Number of  axes : %i\n", (int)data->number_of_axes);
			printf("Number of  buttons : %i\n", (int)data->number_of_buttons);
		case 2 :
			printf("Driver version : %i\n", data->driver_version);
			printf("Joystick name : %s\n", data->joystick_name);
			break;

		default :
			break;
	}
	
	return;
}
