    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#include <sys/mman.h> //mmap
#include <sys/types.h> //off_t
#include <unistd.h> //lseek
#include <fcntl.h> //open
#include <stdlib.h> //exit

#include "../js2mouse.h"

void j2m_remap(struct map_s *map)
{
	int i=0;
	int fd=0;
	off_t length=0;
	void *mem;
	
	if ( (fd = open("/etc/j2m_map", O_RDONLY)) == -1 ) {
		perror("Error when opening '/etc/j2m_map' ");
		exit(-1);
	}
	
	if ( (length=(int)lseek( fd, 0, SEEK_END)) == -1 ) {
		perror("Error when seeking the end of file '/etc/j2m_map' ");
		exit(-1);
	}
	
	if ( (mem=mmap( 0, (size_t)length, PROT_READ, MAP_SHARED, fd, 0)) == MAP_FAILED) {
		perror("Error when mmaping  '/etc/j2m_map'");
		exit(-1);
	}
	
	if ( (i=j2m_parse_map( mem, (size_t)length, map)) ) {
		fprintf( stderr, "Parse error into ~/.j2m_map, line %u\n", i);
		exit(-1);
	}
}
