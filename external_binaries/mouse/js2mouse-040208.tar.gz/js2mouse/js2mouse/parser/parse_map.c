    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    /*
    j2m_map format :
	JOYSTICK_EVENT = MOUSE_EVENT
    it doesn't mind about separator...
    
    JOYSTICK_EVENT are :
	button_1
	button_2
	...
	button_NUMBER_OF_BUTTON
	axe_1
	axe_2
	...
	axe_NUMBER_OF_AXES
    
    MOUSE_EVENT are :
	click_left
	click_right
	click_middle
	click_extra1
	click_extra2
	wheel_up
	wheel_down
	move_horizontal
	move_vertical
    
    Default j2m_map :
	button_1 = click_left
	button_2 = click_right
	button_3 = click_middle
	button_4 = wheel_up
	button_5 = wheel_down
	button_6 = click_extra1
	button_7 = click_extra2
	axe_1 = move_horizontal
	axe_2 = move_vertical
    */

#include <stdlib.h>
#include <string.h>

#include "../js2mouse.h"

unsigned int j2m_parse_map( void *mem, size_t length, struct map_s *map)
{
	size_t offset=0;
	char *buffer;
	char line[128+1];
	unsigned int line_number=0;
	
	while (offset<length) {
		line_number++;

		strncpy( line, mem+offset, 128);
		line[128]='\0';
		line[strcspn( line, "\n")]='\0';

		if ( (buffer=strstr( line, "button_")) || (buffer=strstr( line, "axe_")) ) {
			if ( !j2m_add_key( map, buffer, line) )
				return line_number;
		}

		offset += strlen(line);
		offset++;
	}
	
	return 0;
}



