    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */


#include <stdlib.h>
#include <string.h>

#include "../js2mouse.h"

unsigned char j2m_add_key( struct map_s *map, char *buffer, char *line)
{
	unsigned char number;
	
	if ( !strncmp( buffer, "button_", 7) ) {
		number = (unsigned char)atoi(buffer+7);

		if ( strstr( line, "click_left") ) {
			map->js_click_left=number;
			return 1;
		}
		if ( strstr( line, "click_right") ) {
			map->js_click_right=number;
			return 1;
		}
		if ( strstr( line, "click_middle") ) {
			map->js_click_middle=number;
			return 1;
		}
		if ( strstr( line, "wheel_up") ) {
			map->js_wheel_up=number;
			return 1;
		}
		if ( strstr( line, "wheel_down") ) {
			map->js_wheel_down=number;
			return 1;
		}
		if ( strstr( line, "click_extra1") ) {
			map->js_click_extra1=number;
			return 1;
		}
		if ( strstr( line, "click_extra2") ) {
			map->js_click_extra2=number;
			return 1;
		}
	}
	else {// "axe_"
		number = (unsigned char)atoi(buffer+4);
		
		if ( strstr( line, "move_vertical") ) {
			map->js_move_vertical=number;
			return 1;
		}
		if ( strstr( line, "move_horizontal") ) {
			map->js_move_horizontal=number;
			return 1;
		}
	}
	return 0;
}
