    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
//keep it independant user-mode / kernel-space !!!

#include "exps2.h"
#warning exps2 emulation functions do not work, DO NOT USE THIS PROTOCOL !!!

__s16 dx_exps2=0;
__s16 dy_exps2=0;

signed char j2m_convert_exps2( __u8 type, __s16 value, char *mouse_buff)
{
	signed char ret=NONE;
	signed char move = FALSE; //useful for entering or leaving a 0 value
	static short state=0;

	mouse_buff[3] = 0;
	
	switch (type) {
		case JS_CLICK_LEFT :
			ret = j2m_click_exps2( value, mouse_buff, EXPS2_CLICK_LEFT);
			break;

		case JS_CLICK_RIGHT :
			ret = j2m_click_exps2( value, mouse_buff, EXPS2_CLICK_RIGHT);
			break;

		case JS_CLICK_MIDDLE :
			ret = j2m_click_exps2( value, mouse_buff, EXPS2_CLICK_MIDDLE);
			break;
			
		case JS_CLICK_EXTRA1 :
			if (value) {
				mouse_buff[3] = EXPS2_CLICK_EXTRA1;
				ret = GO;
			}
			break;

		case JS_CLICK_EXTRA2 :
			if (value) {
				mouse_buff[3] = EXPS2_CLICK_EXTRA2;
				ret = GO;
			}
			break;

		case JS_WHEEL_UP :
			if (value) {
				mouse_buff[3] = EXPS2_WHEEL_UP;
				ret = GO;
			}
			break;

		case JS_WHEEL_DOWN :
			if (value) {
				mouse_buff[3] = EXPS2_WHEEL_DOWN;
				ret = GO;
			}
			break;

		case JS_MOVE_HORIZONTAL :
			value = (__s16) (value/2048);
			value = (__s16) (value*value*value/256);
			
			dx_exps2 = value;
			ret = j2m_move_exps2( value, mouse_buff, 1, EXPS2_MOVE_LEFT, EXPS2_MOVE_RIGHT);
			move = TRUE;
			break;

		case JS_MOVE_VERTICAL :
			value = (__s16) (-value/2048);
			value = (__s16) (value*value*value/256);

			dy_exps2 = value;
			ret = j2m_move_exps2( value, mouse_buff, 2, EXPS2_MOVE_DOWN, EXPS2_MOVE_UP);
			move = TRUE;
			break;

		default :
			ret = NONE;
			break;
	}

	switch ( ret ) {
		case NONE :
			if ( AXES_ACTIVE || move )
				ret = GO;
			break;
				
		case DESACTIVED :
			if ( 0 == state)
				break;
			state &= ~(1<< type);
			ret = GO;
			break;
			
		case ACTIVED :
			state |= (1<< type);
			ret = GO;
			break;

		default :
			break;
	}

	if ( AXES_ACTIVE || move )
		j2m_accel_exps2(mouse_buff);

	mouse_buff[0] |= EXPS2_CLICK_RELEASE;

	return ret;
}

