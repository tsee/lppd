    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
#ifndef __JS2MOUSE_H__
#define __JS2MOUSE_H__

#define __J2M_VERSION__ "030921"

#include <stdio.h> //snprintf, perror, fprintf
#include <sys/poll.h> //struct pollfd

#include "map.h"
#include "convert.h"

#define DEFAULT_PROTO "ps2"
#define DEFAULT_DEV "/dev/input/js0"
#define DEFAULT_FIFO "/dev/j2m_fifo"
#define DEFAULT_VERBOSE 3
#define DEFAULT_POLLTIMEOUT 20

#define PS2 1
#define IMPS2 2
#define EXPS2 3 
#define LINKSFB 4

struct option_s
{
	char path_joydev[128+1];
	char path_fifo[128+1];
	char proto[7+1];
	unsigned char verbose;
	unsigned char poll_timeout;
	unsigned char remap;
	struct map_s wanted_map;
};

struct data_s
{
	int fd_joydev;
	int fd_fifo;
	char number_of_axes;
	char number_of_buttons;
	int driver_version;
	char joystick_name[128];
};

void j2m_start( struct option_s *option);
void j2m_init( struct option_s *option, struct data_s *data, unsigned char buff_size);
void j2m_loop( struct pollfd *poll_fd, int fd_joydev, int fd_fifo, unsigned char *map, char *mouse_buff, unsigned char buff_size, unsigned char poll_timeout, unsigned char proto); 

/*Following functions are beta !*/
unsigned int j2m_parse_map( void *mem, size_t length, struct map_s *map);
unsigned char j2m_add_key( struct map_s *map, char *buffer, char *line);
void j2m_remap(struct map_s *map);
#endif //__JS2MOUSE_H__
