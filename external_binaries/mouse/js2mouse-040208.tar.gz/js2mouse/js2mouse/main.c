    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#include <unistd.h> //getopt
#include <stdlib.h> //atoi, exit
#include <string.h> //memset, strncpy

#include "js2mouse.h"

void usage( char *prog_name);

int main( int argc, char **argv)
{
	int rc = 0;
	int optch = 0;

	struct option_s option;
	static char optstring[] = "hrf:d:v:t:p:";

	memset( &option, 0, sizeof(struct option_s));
	
	strncpy( option.path_joydev, DEFAULT_DEV, sizeof(option.path_joydev));
	option.path_joydev[128]='\0';
	
	strncpy( option.path_fifo, DEFAULT_FIFO, sizeof(option.path_fifo));
	option.path_fifo[128]='\0';
	
	strncpy( option.proto, DEFAULT_PROTO, sizeof(option.proto) );
	option.proto[5]='\0';
	
	option.verbose = DEFAULT_VERBOSE;
	option.poll_timeout = DEFAULT_POLLTIMEOUT;
	
	while ( -1 != (optch = getopt( argc, argv, optstring)) ) {
		switch ( optch ) {
			case 'h' :
				rc = 2;
				break;
			case 'd' :
				strncpy( option.path_joydev, optarg, sizeof(option.path_joydev) );
				option.path_joydev[128]='\0';
				break;
			case 'f' :
				strncpy( option.path_fifo, optarg, sizeof(option.path_fifo) );
				option.path_fifo[128]='\0';
				break;
			case 'v' :
				option.verbose = (unsigned char) atoi(optarg);
				break;
			case 't' :
				option.poll_timeout = (unsigned char) atoi(optarg);
				break;
			case 'r' :
				option.remap = 1;
				break;
			case 'p' :
				strncpy( option.proto, optarg, sizeof(option.proto) );
				option.proto[5]='\0';
				break;
			default :   
				rc = 1; 
		}
	}

	if (rc){
		usage(argv[0]);
		exit(rc);
	}

	j2m_start( &option);
	
	//never reached !!!
	return 0;
}



