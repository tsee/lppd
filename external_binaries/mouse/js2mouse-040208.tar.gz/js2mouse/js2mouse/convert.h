    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
#ifndef __CONVERT_H__
#define __CONVERT_H__

#include "js2mouse.h"

#define NONE -1
#define ACTIVED 1
#define DESACTIVED 0

#define GO 2

signed char j2m_convert_ps2( __u8 type, __s16 value, char *mouse_buff);
unsigned char j2m_buffsize_ps2(void);

signed char j2m_convert_imps2( __u8 type, __s16 value, char *mouse_buff);
unsigned char j2m_buffsize_imps2(void);

signed char j2m_convert_exps2( __u8 type, __s16 value, char *mouse_buff);
unsigned char j2m_buffsize_exps2(void);

#endif //__CONVERT_H__

