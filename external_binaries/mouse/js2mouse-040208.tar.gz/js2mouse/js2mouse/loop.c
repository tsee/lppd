    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */

#include <unistd.h> //read, usleep, write
#include <stdlib.h> //exit
#include <string.h> //memset
#include <sys/poll.h> //poll
#include <errno.h> //errno
#include <stdio.h> //perror

#include "js2mouse.h"

void j2m_loop( struct pollfd *poll_fd, int fd_joydev, int fd_fifo, unsigned char *map, char *mouse_buff, unsigned char buff_size, unsigned char poll_timeout, unsigned char proto)
{
	__u8 type=0;
	signed char state=0;
	signed char ret=0;
	struct js_event joy_event;
	signed char (*j2m_convert)( __u8 type, __s16 value, char *mouse_buff);
	
	memset( &joy_event, 0, sizeof(struct js_event));

	switch(proto) {
		case EXPS2 :
			j2m_convert = j2m_convert_exps2;
			break;
		case IMPS2 :
			j2m_convert = j2m_convert_imps2;
			break;
		case PS2 :
			j2m_convert = j2m_convert_ps2;
			break;
		default :
			break;
	}
	
	while(1) {
		if ((ret = poll( poll_fd, 1, poll_timeout)) < 0) {
			perror("Error when waiting for joystick event ");
			exit(-1);
		}

		if ((0 == ret) && (GO != state)) {
			if ((ret = poll( poll_fd, 1, -1)) < 0) {
				perror("Error when waiting for joystick event ");
				exit(-1);
			}
		}

		if ( ret != 0 ) {
			if (( read( fd_joydev, &joy_event, sizeof( struct js_event))) < 0) {
				perror("Error when reading joystick event");
				exit(-1);
			}
		}

		type = j2m_map_it( &joy_event, map);
		
		state = j2m_convert( type, joy_event.value, mouse_buff);

		if  ( GO == state ) {
			if ((write( fd_fifo, mouse_buff, buff_size)) != buff_size) {
				perror("Error  when writing mouse event ");
				exit(-1);
			}
		}

		joy_event.type = 0; //the 0 value is not used for this field in the kernel...
	}
}
