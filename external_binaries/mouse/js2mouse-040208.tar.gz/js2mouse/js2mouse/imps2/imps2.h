    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */

#ifndef __IMPS2_H__
#define __IMPS2_H__

//keep it independant user-mode / kernel-space !!!

#include <linux/joystick.h>
#include "../map.h"
#include "../convert.h"

//The fisrt byte represente ORed actions :
#define IMPS2_CLICK_LEFT 0x9 //1001
#define IMPS2_CLICK_RIGHT 0xa //1010
#define IMPS2_CLICK_MIDDLE 0xc //1100
#define IMPS2_CLICK_RELEASE 0x8 //1000
#define IMPS2_MOVE_LEFT 0x18 //1 1000
#define IMPS2_MOVE_RIGHT 0x8 //1000
#define IMPS2_MOVE_UP 0x8 //1000
#define IMPS2_MOVE_DOWN 0x28 //10 1000

/*The second byte represente the horizontal speed :
-x to the left
x to the right

The fisrt byte represente the vertical speed :
-x to down
x to up

'x' seems to be less than 45 (which is an anourmous value !).*/

//The forth byte represente middle wheel direction :
#define IMPS2_WHEEL_UP 0xff //-1
#define IMPS2_WHEEL_DOWN 0x01 //1

#include "../convert.h"

#define AXES_ACTIVE ((state & (1<<JS_MOVE_HORIZONTAL)) || (state & (1<<JS_MOVE_VERTICAL)) )
#define TRUE 1
#define FALSE 0

extern __s16 dx_imps2;
extern __s16 dy_imps2;

void j2m_accel_imps2(char *mouse_buff);
unsigned char j2m_click_imps2( __s16 value, char *mouse_buff, signed char click);
unsigned char j2m_move_imps2( __s16 value, char *mouse_buff, signed char rank, signed char neg_move, signed char pos_move);

#endif //__PS2_H__

