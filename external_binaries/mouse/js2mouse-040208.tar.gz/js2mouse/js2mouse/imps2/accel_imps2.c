    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
//keep it independant user-mode / kernel-space !!!

#include "imps2.h"

void j2m_accel_imps2(char *mouse_buff)
{
	if ( dx_imps2 != 0 ) {
		if ( (dx_imps2 - mouse_buff[1])<0 )
			mouse_buff[1] = mouse_buff[1]-1;
		if ( (dx_imps2 - mouse_buff[1])>0 )
			mouse_buff[1] = mouse_buff[1]+1;
	}
	else mouse_buff[1] = 0;

	if ( dy_imps2 != 0 ) {
		if ( (dy_imps2 - mouse_buff[2])<0 )
			mouse_buff[2] = mouse_buff[2]-1;
		if ( (dy_imps2 - mouse_buff[2])>0 )
			mouse_buff[2] = mouse_buff[2]+1;
	}
	else mouse_buff[2] = 0;
}

