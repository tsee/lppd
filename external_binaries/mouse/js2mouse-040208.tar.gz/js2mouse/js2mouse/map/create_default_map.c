    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#include "../map.h"

//keep it independant user-mode / kernel-space !!!

void j2m_create_default_map(unsigned char *map, unsigned char number_of_axes, unsigned char number_of_buttons)
{
	int i=0;
	
	map[0] = number_of_buttons;
	
	for ( i=1; i<number_of_buttons+number_of_axes+1; i++) {
		map[i] = JS_UNUSED;
	}

	map[1] = JS_CLICK_LEFT;
	map[2] = JS_CLICK_RIGHT;
	map[3] = JS_CLICK_MIDDLE;
	map[4] = JS_WHEEL_UP;
	map[5] = JS_WHEEL_DOWN;
	map[6] = JS_CLICK_EXTRA1;
	map[7] = JS_CLICK_EXTRA2;
	map[map[0]+1] = JS_MOVE_HORIZONTAL;
	map[map[0]+2] = JS_MOVE_VERTICAL;
}
