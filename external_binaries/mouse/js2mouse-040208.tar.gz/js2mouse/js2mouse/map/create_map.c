    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */

    
#include "../map.h"

//keep it independant user-mode / kernel-space !!!

void j2m_create_map( struct map_s *wanted_map, unsigned char *map, unsigned char number_of_axes, unsigned char number_of_buttons)
{
	int i=0;
	
	if (wanted_map->js_click_left > number_of_buttons ||
		wanted_map->js_click_right > number_of_buttons ||
		wanted_map->js_click_middle > number_of_buttons ||
		wanted_map->js_click_extra1 > number_of_buttons ||
		wanted_map->js_click_extra2 > number_of_buttons ||
		wanted_map->js_wheel_up > number_of_buttons ||
		wanted_map->js_wheel_down > number_of_buttons ||
		wanted_map->js_move_vertical > number_of_axes ||
		wanted_map->js_move_horizontal > number_of_axes ) {
		j2m_create_default_map(map, number_of_axes , number_of_buttons);
		return;
	}

	map[0] = number_of_buttons;

	for ( i=1; i<number_of_buttons+number_of_axes+1; i++) {
		map[i] = JS_UNUSED;
	}

	map[wanted_map->js_click_left] = JS_CLICK_LEFT;
	map[wanted_map->js_click_right] = JS_CLICK_RIGHT;
	map[wanted_map->js_click_middle] = JS_CLICK_MIDDLE;
	map[wanted_map->js_click_extra1] = JS_CLICK_EXTRA1;
	map[wanted_map->js_click_extra2] = JS_CLICK_EXTRA2;
	map[wanted_map->js_wheel_up] = JS_WHEEL_UP;
	map[wanted_map->js_wheel_down] = JS_WHEEL_DOWN;
	map[wanted_map->js_move_vertical+map[0]] = JS_MOVE_VERTICAL;
	map[wanted_map->js_move_horizontal+map[0]] = JS_MOVE_HORIZONTAL;

	
}



