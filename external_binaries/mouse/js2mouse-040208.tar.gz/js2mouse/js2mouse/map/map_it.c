    /*
    Js2Mouse, convert joystick events into mouse events
    Copyright (C) 2003  VINCENT C�dric

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    */
    
    
#include "../map.h"

//keep it independant user-mode / kernel-space !!!

__u8 j2m_map_it( struct js_event *joy_event, unsigned char *map)
{
	__u8 type=0;
	
	joy_event->type &= ~JS_EVENT_INIT;
	
	switch (joy_event->type) {
		case JS_EVENT_BUTTON :
			type = map[joy_event->number+1];
			break;
		case JS_EVENT_AXIS :
			type = map[joy_event->number+map[0]+1]; //map[0] = number_of_buttons
			break;
		default :
			type = JS_UNUSED;
			break;
	}
	
	return type;
}

